﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl.Models.Interfaces
{
    public interface IIdentify
    {
       
        public string Id { get; set; }
    }
}
