﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl.Core.Interfaces
{
   public interface IEngine
    {
        public void Run();
    }
}
