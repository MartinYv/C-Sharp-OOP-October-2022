﻿using Heroes.Models.Contracts;
using Heroes.Models.Heroes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Heroes.Models.Map
{
    public class Map : IMap
    {
        public string Fight(ICollection<IHero> players)
        {
            List<IHero> barbarians = new List<IHero>();
            List<IHero> knights = new List<IHero>();


            foreach (IHero hero in players)
            {
                if (hero.GetType().Name == "Barbarian")
                {
                    barbarians.Add(hero);
                }
                else
                {
                    knights.Add(hero);
                }
            }

            int row = 0;
            while (barbarians.Count > 0 && knights.Count > 0)
            {
                if (true)
                {


                    for (int k = row; k < knights.Count; k++)
                    {
                        int damage = knights[k].Weapon.Damage;

                        for (int b = 0; b < barbarians.Count; b++)
                        {
                            barbarians[b].TakeDamage(damage);
                        }
                        row++;
                    }
                }
                else
                {
                    for (int b  = row; b < barbarians.Count; b++)
                    {
                        int damage = barbarians[b].Weapon.Damage;

                        for (int k = 0; k < barbarians.Count; k++)
                        {
                            barbarians[k].TakeDamage(damage);
                        }
                        row++;
                    }
                }
            }
        }
    }
}

