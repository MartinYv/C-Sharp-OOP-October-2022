﻿using Heroes.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Heroes.Models.Weapons
{
    public abstract class Weapon : IWeaponDmg, IWeapon
    {
        protected Weapon()
        {
        }

        public string Name => throw new NotImplementedException();

        public int Durability => throw new NotImplementedException();

        public int DoDamage()
        {
            throw new NotImplementedException();
        }
    }
}
