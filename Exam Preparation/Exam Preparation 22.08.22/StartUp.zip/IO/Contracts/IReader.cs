﻿namespace BookingApp.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
