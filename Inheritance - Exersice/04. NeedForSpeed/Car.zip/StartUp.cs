﻿namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //  SportCar – DefaultFuelConsumption = 10
            //
            // RaceMotorcycle – DefaultFuelConsumption = 8
            //
            // Car – DefaultFuelConsumption = 3

            // int horsePower, double fuel

          
        }
    }
}
